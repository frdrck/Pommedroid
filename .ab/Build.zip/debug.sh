tns device log
