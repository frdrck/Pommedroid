appbuilder build android --download
