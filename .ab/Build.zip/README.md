# Pommedroid
New Repo

Wooo hooo!!!

Android Build Instructions:
  navigate to top directory with app dir and README.md and run:
  appbuilder build android --download

  This builds and downloads Pommedroid.apk
  Run the apk on a phone or in an emulator.

Android emulator Debug instructions:
  run:
  tns device log

